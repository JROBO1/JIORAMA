#!/usr/bin/env python3

import RPi.GPIO as GPIO # RPi.GPIOモジュールを使用
import struct, binascii, serial
import time
import threading
import queue

def sendTWELite1(s, sendto = 0x01,#gousya
        digital = [-1, -1, -1, -1],
        analog = [-1, -1, -1, -1]):
    # 先頭3バイト
    data = [sendto, 0x80, 0x01]
        
    # デジタル出力
    do = 0
    domask = 0
    for index, value in enumerate(digital):
        if value >= 0:
            domask |= 1 << index
            do |= (value & 1) << index
    data.append(do)
    data.append(domask)
    print(digital)
    # アナログ出力
    for index, value in enumerate(analog):
        if value >= 0 and value <= 100:
            v = int(1024 * value / 100)
            data.append(v >> 8)
            data.append(v & 0xff)
        else:
            data.append(0xff)
            data.append(0xff)
    print(analog)

    # チェックサムを計算する
    chksum = 0
    for val in data:
        chksum = (chksum + val) & 0xff
    data.append((0x100 - chksum) & 0xff)

    # 16進数文字列に変換する
    ss = struct.Struct("14B")
    outstring = str(binascii.hexlify(ss.pack(*data)), 'utf-8').upper()
    print(outstring)
    # TWE-Liteに送信する
    s.write(bytes(":" + outstring + "\r\n", 'utf-8'))
    return
def sendTWELite2(s, sendto = 0x02,#gousya
        digital = [-1, -1, -1, -1],
        analog = [-1, -1, -1, -1]):
    # 先頭3バイト
    data = [sendto, 0x80, 0x01]
        
    # デジタル出力
    do = 0
    domask = 0
    for index, value in enumerate(digital):
        if value >= 0:
            domask |= 1 << index
            do |= (value & 1) << index
    data.append(do)
    data.append(domask)
    print(digital)
    # アナログ出力
    for index, value in enumerate(analog):
        if value >= 0 and value <= 100:
            v = int(1024 * value / 100)
            data.append(v >> 8)
            data.append(v & 0xff)
        else:
            data.append(0xff)
            data.append(0xff)
    print(analog)

    # チェックサムを計算する
    chksum = 0
    for val in data:
        chksum = (chksum + val) & 0xff
    data.append((0x100 - chksum) & 0xff)

    # 16進数文字列に変換する
    ss = struct.Struct("14B")
    outstring = str(binascii.hexlify(ss.pack(*data)), 'utf-8').upper()
    print(outstring)
    # TWE-Liteに送信する
    s.write(bytes(":" + outstring + "\r\n", 'utf-8'))
    return
s = serial.Serial("/dev/ttyUSB0", 115200)#tweli
def ContFFast1():
    # 前進方向
    sendTWELite1(s, digital=[1,-1,-1,-1])
    time.sleep(1.0)
    # 前進低速
    sendTWELite1(s, analog=[0, 80, -1, -1])
    return
def ContFFast2():
    # 前進方向
    sendTWELite2(s, digital=[1,-1,-1,-1])
    time.sleep(1.0)
    # 前進低速
    sendTWELite2(s, analog=[0, 80, -1, -1])
    return
while 1:
    ContFFast1()
    time.sleep(0.5)
    ContFFast2()
    time.sleep(0.5)
    """
    sendTWELite1(s, digital=[1, -1, -1, -1])
    time.sleep(0.5)
    sendTWELite1(s, digital=[0, -1, -1, -1])
    time.sleep(0.5)
    #print(digital)
    sendTWELite2(s, digital=[1, -1, -1, -1])
    time.sleep(0.5)
    sendTWELite2(s, digital=[0, -1, -1, -1])
    time.sleep(0.5)
    #print(outstring)
    #s.write(bytes(":7880010F0F0000000000000000E9\r\n",'utf-8'))
    #sendTWELite(s, analog = [2,2,2,2])
    #time.sleep(0.5)
    #s.write(bytes(":"+0081150190810043E0781411000CAA15070F5679FFFFFBEF+"\r\n", 'utf-8'))
    """
s.close()
#:0081150190810043E0781411000CAA15070F5679FFFFFBEF
    
