import struct,binascii
import serial

#コマンド0x81を解釈する関数
def parseTWELite(data):
    #先頭の[:]を取り除く
    if data[0] !=ord(":"):
        return False
    data=data[1:]
   
    #バイトデータに変換する
    ss=struct.Struct(">BBBBBIBHBHBBBBBBBBB")
    data=binascii.unhexlify(data.rstrip())
    parsed=ss.unpack(data)

    #デジタル入力/アナログ入力の値を計算)す
    digital=[0]*4
    digitalchanged=[0]*4
    analog=[0xffff]*4

    for i in range(4):
        #デジタル入力
        if parsed[11] & (1<<i):
            digital[i]=1
        else:
            digital[i]=0
        if parsed[12] & (1<<i):
            digitalchanged[I]=1
        else:
            digitalchanged[I]=0
        #アナログ入力
        if parsed[13+i]==0xff:
            analog[i]=0xffff
        else:
            analog[i]=(parsed[13+i]*4+((parsed[17]>>(2<<i))&3))*4

     #結果を返す
    result={
         "from" : parsed[0],
         "lqi" : parsed[4],
         "fromid" : parsed[5],
         "to": parsed[7],
         "timestamp": parsed[7],
         "isrelay": parsed[8],
         "baterry": parsed[9],
         "digital": digital,
         "digitalchanged": digitalchanged,
         "analog": analog
    }
    return result

#com3を開く
s=serial.Serial("/dev/ttyUSB0",115200)

#1行読み取る
data=s.readline()

#解釈する
parsed=parseTWELite(data)
print(parsed)

#comを閉じる
s.close()

