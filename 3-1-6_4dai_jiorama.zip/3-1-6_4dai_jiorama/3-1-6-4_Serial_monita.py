import serial
import time
 
ser = serial.Serial('/dev/ttyUSB1',9600, timeout=0)   #
 
while True:
    #time.sleep(5)
    line = ser.readline()
    #if line>0:
    print(line)# ここに受信があった時の処理
    time.sleep(0.5)
    #else:
        # ここに受信がなかった時の処理
 
ser.close()