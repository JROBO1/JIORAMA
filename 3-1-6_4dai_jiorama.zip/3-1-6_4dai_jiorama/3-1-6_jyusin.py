#!/usr/bin/env python
# -*- coding: utf-8 -*-
import serial
s=serial.Serial("/dev/ttyUSB0",115200)
                
while 1:
    data=s.readline()
    print(data)
    
s.close()
