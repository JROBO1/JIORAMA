import struct, binascii, serial

# コマンド0x81を解釈する関数
def parseTWELite(data):
    # 先頭の「:」を取り除く
    if data[0] != ord(":"):
        return False
    data = data[1:]

    # バイトデータに変換する
    ss = struct.Struct(">BBBBBIBHBHBBBBBBBBB")
    data = binascii.unhexlify(data.rstrip())
    parsed = ss.unpack(data)

    # デジタル入力／アナログ入力の値を計算する
    digital = [0] * 4
    digitalchanged = [0] * 4
    analog = [0xffff] * 4

    for i in range(4):
        # デジタル入力
        if parsed[11] & (1 << i):
            digital[i] = 1
        else:
            digital[i] = 0
        if parsed[12] & (1 << i):
            digitalchanged[i] = 1
        else:
            digitalchanged[i] = 0

        # アナログ入力
        if parsed[13 + i] == 0xff :
            analog[i] = 0xffff
        else:
            analog[i] = (parsed[13 + i] * 4 + ((parsed[17] >> (2 << i)) & 3)) * 4


    # 結果を返す
    result = {
        "from" : parsed[0],
        "lqi" : parsed[4],
        "fromid" : parsed[5],
        "to": parsed[6],
        "timestamp": parsed[7],
        "isrelay": parsed[8],
        "baterry" : parsed[9],
        "digital" : digital,
        "digitalchanged" : digitalchanged,
        "analog" : analog
    }
    return result

# COM3を開く
s = serial.Serial("/dev/ttyUSB0", 115200)

while 1:
    # 1行読み取る
    data = s.readline()
    parsed = parseTWELite(data)
    # バッテリー電圧監視
    bv = (parsed["analog"][0])
    print(bv)

# COMを閉じる
s.close()
