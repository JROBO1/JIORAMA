# 20210117 INIT処理＜K1>
# 20210119 定時列車スタート機能
# 20210124 Sub側1号車のみ
# 20210130 Main側2号機のみ
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
import RPi.GPIO as GPIO
import struct, binascii, serial
import time
import datetime

GPIO_Stanby = 17
GPIO_arduinoON = 16
Train = ["0"] * 6

StartSub1 = 0
StartSub2 = 0 
StartSub3 = 0 
StartSub4 = 0 
StartMain1 = 0 
StartMain2 = 0 
StartMain3 = 0 
StartMain4 = 0 

TimeSetSub = 0
TimeSetMain = 0

iSub = 0 
iMain = 0 

FG9 = 0 
FG10 = 0
FG13_21 = 0
FG22_32 = 0 

TrCont1 = 0
TrCont2 = 0
TrCont3 = 0
TrCont4 = 0

Buff = "0"
Bufsep = "0"

TT1=[  5, 10,  30,   5,  10,   4,  20,  20,  20]
TT2=[ 70, 15,   6,  10,   5,  15,  30,  40,  10]

GPIO.setmode(GPIO.BCM)
GPIO.setup(GPIO_Stanby, GPIO.IN)
GPIO.setup(GPIO_arduinoON, GPIO.OUT)

stick = serial.Serial("/dev/ttyUSB0", 115200)
serMEGA = "/dev/ttyACM0"
#serMEGA.flush()
#time.sleep(1)

if __name__ == '__main__':
    print('start waiting')
    # GPIOの初期化
    # GPIO設定
    GPIO.output(GPIO_arduinoON, 0)
    uno.send_serial("I")
    JG = GPIO.input(GPIO_Stanby)
    while not JG:
        JG = GPIO.input(GPIO_Stanby)
    serMEGA.write("G")
    time.sleep(1)

def Dispatch():
    global FG10 
    
    if((Train[0]=="10" or Train[1]=="10") and FG10==0):
        now1 = datetime.datetime.now()
        TimeSet1 = now1 + datetime.timedelta(seconds=15)
        FG10 = 1           
        return TimeSet1  

def DispatchSub():
    global StartSub1 
    global StartSub2
    global StartSub3
    global StartSub4
    global iSub
    global FG22_32 
    
    if(Train[0]=="22" and StartSub1==0 and FG22_32==0):
        now = datetime.datetime.now()
        TimeSetSub = now + datetime.timedelta(seconds=TT1[iSub])
        print("DispatchSub")
        StartSub1 = 1     
        iSub = iSub + 1  
        return TimeSetSub
    
    if(Train[1]=="22" and StartSub2==0 and FG22_32==0):
        now = datetime.datetime.now()
        TimeSetSub = now + datetime.timedelta(seconds=TT1[iSub])
        StartSub2 = 1      
        iSub = iSub + 1   
        return TimeSetSub
    
    if(Train[2]=="22" and StartSub3==0 and FG22_32==0):
        now = datetime.datetime.now()
        TimeSetSub = now + datetime.timedelta(seconds=TT1[iSub])
        StartSub3 = 1      
        iSub = iSub + 1    
        return TimeSetSub 
    
    if(Train[3]=="22" and StartSub4==0 and FG22_32==0):
        now = datetime.datetime.now()
        TimeSetSub = now + datetime.timedelta(seconds=TT1[iSub])
        StartSub4 = 1     
        iSub = iSub + 1  
        return TimeSetSub  

def DispatchMain():
    global StartMain1  
    global StartMain2
    global StartMain3
    global StartMain4
    global iMain
    global FG22_32  
    
    if(Train[0]=="32" and StartMain1==0 and FG22_32==0):
        now = datetime.datetime.now()
        TimeSetMain = now + datetime.timedelta(seconds=TT2[iMain])
        StartMain1 = 1      
        iMain = iMain + 1  
        return TimeSetMain  
    
    if(Train[1]=="32" and StartMain2==0 and FG22_32==0):
        now = datetime.datetime.now()
        TimeSetMain = now + datetime.timedelta(seconds=TT2[iMain])
        StartMain2 = 1      
        iMain = iMain + 1   
        return TimeSetMain 
    
    if(Train[2]=="32" and StartMain3==0 and FG22_32==0):
        now = datetime.datetime.now()
        TimeSetMain = now + datetime.timedelta(seconds=TT2[iMain])
        StartMain3 = 1      
        iMain = iMain + 1   
        return TimeSetMain   
    
    if(Train[3]=="32" and StartMain4==0 and FG22_32==0):
        now = datetime.datetime.now()
        TimeSetMain = now + datetime.timedelta(seconds=TT2[iMain])
        StartMain4 = 1      
        iMain = iMain + 1  
        return TimeSetMain

def DispatchSubReset():
    global StartSub1
    global StartSub2
    global StartSub3
    global StartSub4
    global StartMain1
    global StartMain2
    global StartMain3
    global StartMain4
    global FG9
    global FG10
    global FG13_21
    global FG22_32
    
    if(Train[0]=="4"):
        StartSub1 = 0     
        StartMain1 = 0
        FG13_21 = 0
        FG22_32 = 1        
        FG9 = 0
        FG10 = 0
        return
    
    if(Train[1]=="4"):
        StartSub2 = 0  
        StartMain2 = 0
        FG13_21 = 0
        FG22_32 = 1        # <K4>
        FG9 = 0
        FG10 = 0
        return
    
    if(Train[2]=="4"):
        StartSub3 = 0     
        StartMain3 = 0
    
    if(Train[3]=="4"):
        StartSub4 = 0     
        StartMain4 = 0

def startWaiteSubHome(t_now, SetSubtime):
    global StartSub1
    global TrCont1
    print("StartSub1=1")
    print(StartSub1)
    if(StartSub1 == 1):
        if(SetSubtime < t_now):
            TrCont1 = 1         
            return
    
def startWaiteMainHome(t_now, SetMaintime):
    global StartMain1
    global StartMain2
    global TrCont1
    global TrCont2
    if(StartMain1 == 1):
        if(SetMaintime < t_now):
            TrCont1 = 1       
            return
    
    if(StartMain2 == 1):
        if(SetMaintime < t_now):
            TrCont2 = 1        
            return
    
def startWaite(t_now, SetNo1time):
    global TrCont1
    global FG10
    global FG13_21
    
    if(FG10==1):
        if(SetNo1time < t_now):
            FG10 = 0
            FG13_21 = 0
            TrCont1 = 1        
            return
    

def Decelerate():
    global FG9
    global TrCont1
    
    if((Train[0]=="8" or Train[1]=="8" or Train[2]=="8" or Train[3]=="8") and
       (FG9==0)):
        print("減速")
        TrCont1 = 2    
        FG9 = 1

def DecelerateHome():
    global FG13_21
    global TrCont1

    if((Train[0]=="13" or Train[1]=="13" or Train[2]=="13" or Train[3]=="13" or
       Train[0]=="21" or Train[1]=="21" or Train[2]=="21" or Train[3]=="21") and
       (FG13_21==0)):
        TrCont1 = 2
        FG13_21 = 1


def stopCont():
    global FG9
    global TrCont1

    if((Train[0]=="10" or Train[1]=="10") and FG9==1):
        TrCont1 = 3
        FG9 = 0

def stopHomeCont():
    global FG22_32
    global FG13_21
    global TrCont1

    if(Train[0]=="22" and FG22_32==1):
        TrCont1 = 3
        StartSub1 = 0
        FG22_32 = 0      # <K5>
        FG13_21 = 0      # <K6>


def TrContJG():
    global TrCont1
    global TrCont2
    global TrCont3
    global TrCont4
    
    if TrCont1 == 1:       
        ContFSlow1()
    
    if TrCont1 == 2:       
        ContFMSlow1()
    
    if TrCont1 == 3:       
        ContStop1()

    if TrCont2 == 1:      
#        print("Slow")
        ContFSlow2()
    
    if TrCont2 == 2:      
        ContFMSlow2()
    
    if TrCont2 == 3:      
        ContStop2()


def OutPointJudg():
    global TimeSetSub
    global TimeSetMain
    
    now = datetime.datetime.now()
    
    if((Train[0]=="32" or Train[1]=="32" or Train[2]=="32" or Train[3]=="32") and
       (not (Train[0]=="22" or Train[1]=="22" or Train[2]=="22" or Train[3]=="22"))):
        serMEGA.write(b"M\n")
    
    if not(TimeSetSub==None or TimeSetMain==None):
        if(TimeSetSub < TimeSetMain):
            serMEGA.write(b"S\n")
    
    if not(TimeSetSub==None or TimeSetMain==None):
        if(TimeSetSub > TimeSetMain):
            serMEGA.write(b"M\n")
            
    if not(TimeSetMain==None) and (TimeSetSub==None):
        serMEGA.write(b"M\n")
        
    if (TimeSetMain==None) and (TimeSetSub==None):
        serMEGA.write(b"M\n")


def sendTWELite(stick, sendto = 0x00,
        digital = [-1, -1, -1, -1],
        analog  = [-1, -1, -1, -1]):
    data = [sendto, 0x80, 0x01]
    
    do = 0
    domask = 0
    for index, value in enumerate(digital):
        if value >= 0:
            domask |= 1 << index
            do |= (value & 1) << index
    data.append(do)
    data.append(domask)
    
    for index, value in enumerate(analog):
        if value >= 0 and value <= 100:
            v = int(1024 * value / 100)
            data.append(v >> 8)
            data.append(v & 0xff)
        else:
            data.append(0xff)
            data.append(0xff)

    chksum = 0
    for val in data:
        chksum = (chksum + val) & 0xff
    data.append((0x100 - chksum) & 0xff)
    ss = struct.Struct("14B")
    outstring = str(binascii.hexlify(ss.pack(*data)), 'utf-8').upper()
    stick.write(bytes(":" + outstring + "\r\n", 'utf-8'))
    return

def parseTWELite(data):
    ss = struct.Struct(">BBBBBIBHBHBBBBBBBBB")
    data = binascii.unhexlify(data.rstrip())
    parsed = ss.unpack(data)

    digital = [0] * 4
    digitalchanged = [0] * 4
    analog = [0xffff] * 4

    for i in range(4):
        if parsed[11] & (1 << i):
            digital[i] = 1
        else:
            digital[i] = 0
        if parsed[12] & (1 << i):
            digitalchanged[i] = 1
        else:
            digitalchanged[i] = 0

        if parsed[13 + i] == 0xff :
            analog[i] = 0xffff
        else:
            analog[i] = (parsed[13 + i] * 4 + ((parsed[17] >> (2 << i)) & 3)) * 4

    result = {
        "from" : parsed[0],
        "lqi" : parsed[4],
        "fromid" : parsed[5],
        "to": parsed[6],
        "timestamp": parsed[7],
        "isrelay": parsed[8],
        "baterry" : parsed[9],
        "digital" : digital,
        "digitalchanged" : digitalchanged,
        "analog" : analog
    }
    return result

def ContFFast1():
    sendTWELite(stick, sendto = 0x01, digital=[0, 1, 0, 1], analog=[0, 80, -1, -1])
    return

def ContFSlow1():
    sendTWELite(stick, sendto = 0x01, digital=[0, 1, 0, 1], analog=[0, 50, -1, -1])
    return

def ContFMSlow1():
    sendTWELite(stick, sendto = 0x01, digital=[0, 1, 0, 1], analog=[0, 39, -1, -1])
    return

def ContRSlow1():
    sendTWELite(stick, sendto = 0x01, digital=[1, 0, 1, 0], analog=[60, 0, -1, -1])
    return

def ContRFast1():
    sendTWELite(stick, sendto = 0x01, digital=[1, 0, 1, 0], analog=[80, 0, -1, -1])
    return

def ContStop1():
    sendTWELite(stick, sendto = 0x01, analog=[100, 100, -1, -1], digital=[1, 1, 1, 1])
    return

def readline1():
    data = stick.readline()
    data = data[1:]
    if(len(data)==50):
        parsed = parseTWELite(data)
        baterry = (parsed["analog"][0])
        distance = (parsed["analog"][1])
        print(baterry)
        print(distance)

def ContFFast2():
    sendTWELite(stick, sendto = 0x02, digital=[0, 1, 0, 1], analog=[0, 80, -1, -1])
    return

def ContFSlow2():
    sendTWELite(stick, sendto = 0x02, digital=[0, 1, 0, 1], analog=[0, 55, -1, -1])
    return

def ContFMSlow2():
    sendTWELite(stick, sendto = 0x02, digital=[0, 1, 0, 1], analog=[0, 43, -1, -1])
    return

def ContRSlow2():
    sendTWELite(stick, sendto = 0x02, digital=[1, 0, 1, 0], analog=[60, 0, -1, -1])
    return

def ContRFast2():
    sendTWELite(stick, sendto = 0x02, digital=[1, 0, 1, 0], analog=[80, 0, -1, -1])
    return

def ContStop2():
    sendTWELite(stick, sendto = 0x02, analog=[100, 100, -1, -1], digital=[1, 1, 1, 1])
    return

def readline2():
    data = stick.readline()
    data = data[1:]
    if(len(data)==50):
        parsed = parseTWELite(data)
        baterry = (parsed["analog"][0])
        distance = (parsed["analog"][1])
        print(baterry)
        print(distance)

def ContFFast3():
    sendTWELite(stick, sendto = 0x03, digital=[0, 1, 0, 1], analog=[0, 80, -1, -1])
    return

def ContFSlow3():
    sendTWELite(stick, sendto = 0x03, digital=[0, 1, 0, 1], analog=[0, 55, -1, -1])
    return

def ContFMSlow3():
    sendTWELite(stick, sendto = 0x03, digital=[0, 1, 0, 1], analog=[0, 40, -1, -1])
    return

def ContRSlow3():
    sendTWELite(stick, sendto = 0x03, digital=[1, 0, 1, 0], analog=[60, 0, -1, -1])
    return

def ContRFast3():
    sendTWELite(stick, sendto = 0x03, digital=[1, 0, 1, 0], analog=[80, 0, -1, -1])
    return

def ContStop3():
    sendTWELite(stick, sendto = 0x03, analog=[100, 100, -1, -1], digital=[1, 1, 1, 1])
    return

def readline3():
    data = stick.readline()
    data = data[1:]
    if(len(data)==50):
        parsed = parseTWELite(data)
        baterry = (parsed["analog"][0])
        distance = (parsed["analog"][1])
        print(baterry)
        print(distance)

def ContFFast4():
    sendTWELite(stick, sendto = 0x04, digital=[0, 1, 0, 1], analog=[0, 80, -1, -1])
    return

def ContFSlow4():
    sendTWELite(stick, sendto = 0x04, digital=[0, 1, 0, 1], analog=[0, 55, -1, -1])
    return

def ContFMSlow4():
    sendTWELite(stick, sendto = 0x04, digital=[0, 1, 0, 1], analog=[0, 40, -1, -1])
    return

def ContRSlow4():
    sendTWELite(stick, sendto = 0x04, digital=[1, 0, 1, 0], analog=[60, 0, -1, -1])
    return


    sendTWELite(stick, sendto = 0x04, digital=[1, 0, 1, 0], analog=[80, 0, -1, -1])
    return

def ContStop4():
    sendTWELite(stick, sendto = 0x04, analog=[100, 100, -1, -1], digital=[1, 1, 1, 1])
    return

def readline4():
    data = stick.readline()
    data = data[1:]
    if(len(data)==50):
        parsed = parseTWELite(data)
        baterry = (parsed["analog"][0])
        distance = (parsed["analog"][1])
        print(baterry)
        print(distance)

def trainPoji():
    uno.send_serial("R")
    time.sleep(1)
    Buf = uno.receive_serial()
    print("Buf ",Buf," ;;;")


def trainPoji():
    global Train
    serMEGA.write(b"R\n")
    time.sleep(0.1)
    Buf = serMEGA.readline().decode('utf-8').rstrip()
    print(Buf)
    print(len(Buf))
    if(len(Buf)==11 or len(Buf)):
        Train = Buf.split(",")
//    return TrainB


class USBSerial:
    def __init__(self, path):
        try:
            self.serialport = serial.Serial(
                port=path,
                baudrate=2000000,
                bytesize=serial.EIGHTBITS,
                parity=serial.PARITY_NONE,
                stopbits=serial.STOPBITS_ONE,
                timeout=0.5,
            )
        except serial.SerialException:
            print(traceback.format_exc())

        self.serialport.reset_input_buffer()
        self.serialport.reset_output_buffer()
        time.sleep(1)

    def send_serial(self, cmd):
        try:
            cmd.rstrip()
            self.serialport.write((cmd + "\n").encode("utf-8"))
        except serial.SerialException:
            print(traceback.format_exc())

    def receive_serial(self):
        try:
            rcvdata = self.serialport.readline()
        except serial.SerialException:
            print(traceback.format_exc())
        return rcvdata.decode("utf-8").rstrip()

if __name__=='__main__':
    uno = USBSerial(serMEGA)
    print('start waiting')
    GPIO.output(GPIO_arduinoON, 0)
    uno.send_serial("I")
    JG = GPIO.input(GPIO_Stanby)
    while not JG:
        JG = GPIO.input(GPIO_Stanby)
    uno.send_serial("G")
    time.sleep(1)
    while 1:
        trainPoji()
        print(Train)
        print("****************")
        print("Train1= ", Train[0])
        print("Train2= ", Train[1])
        print("Train3= ", Train[2])
        print("Train4= ", Train[3])
        print("****************")
        if(FG10 == 0):
            SetNo1time = Dispatch()
        if(StartSub1 == 0):   
            SetSubtime = DispatchSub()   
        if(StartMain2 == 0):  
            SetMaintime = DispatchMain()    
        t_now = datetime.datetime.now()
        print("t_now")
        print(t_now)
        print("SetMaintime")
        print(SetMaintime)
        OutPointJudg()
        startWaite(t_now, SetNo1time)
        startWaiteSubHome(t_now, SetSubtime)
        startWaiteMainHome(t_now, SetMaintime)
        Decelerate()
        DecelerateHome()
        stopCont()
        stopHomeCont()
        TrContJG()
        DispatchSubReset()
        if(iSub > 7):
            iSub = 0
        if(iMain > 7):
            iMain = 0

GPIO.output(GPIO_arduinoON, 1)
stick.close()
serMEGA.close()
GPIO.cleanup()
